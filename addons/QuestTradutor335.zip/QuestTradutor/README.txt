Este addon é uma modificação do Addon https://www.curseforge.com/wow/addons/quest-translator
e foi mesclado com o outro addon do mesmo criador: https://www.curseforge.com/wow/addons/wow-translator

Modificação feita por https://github.com/leoaviana/